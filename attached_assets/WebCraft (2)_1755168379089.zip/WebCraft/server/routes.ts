import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertHospitalSchema,
  insertHealthUnitSchema,
  insertDialysisCenterSchema,
  insertEmergencyServiceSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all hospitals
  app.get("/api/hospitals", async (req, res) => {
    try {
      const hospitals = await storage.getAllHospitals();
      res.json(hospitals);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch hospitals" });
    }
  });

  // Get hospital by ID
  app.get("/api/hospitals/:id", async (req, res) => {
    try {
      const hospital = await storage.getHospital(req.params.id);
      if (!hospital) {
        return res.status(404).json({ message: "Hospital not found" });
      }
      res.json(hospital);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch hospital" });
    }
  });

  // Create hospital
  app.post("/api/hospitals", async (req, res) => {
    try {
      const validation = insertHospitalSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid hospital data", errors: validation.error.errors });
      }
      
      const hospital = await storage.createHospital(validation.data);
      res.status(201).json(hospital);
    } catch (error) {
      res.status(500).json({ message: "Failed to create hospital" });
    }
  });

  // Health Units routes
  app.get("/api/health-units", async (req, res) => {
    try {
      const healthUnits = await storage.getAllHealthUnits();
      res.json(healthUnits);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch health units" });
    }
  });

  app.get("/api/health-units/:id", async (req, res) => {
    try {
      const healthUnit = await storage.getHealthUnit(req.params.id);
      if (!healthUnit) {
        return res.status(404).json({ message: "Health unit not found" });
      }
      res.json(healthUnit);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch health unit" });
    }
  });

  app.post("/api/health-units", async (req, res) => {
    try {
      const validation = insertHealthUnitSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid health unit data", errors: validation.error.errors });
      }
      
      const healthUnit = await storage.createHealthUnit(validation.data);
      res.status(201).json(healthUnit);
    } catch (error) {
      res.status(500).json({ message: "Failed to create health unit" });
    }
  });

  // Dialysis Centers routes
  app.get("/api/dialysis-centers", async (req, res) => {
    try {
      const dialysisCenters = await storage.getAllDialysisCenters();
      res.json(dialysisCenters);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dialysis centers" });
    }
  });

  app.get("/api/dialysis-centers/:id", async (req, res) => {
    try {
      const dialysisCenter = await storage.getDialysisCenter(req.params.id);
      if (!dialysisCenter) {
        return res.status(404).json({ message: "Dialysis center not found" });
      }
      res.json(dialysisCenter);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dialysis center" });
    }
  });

  app.post("/api/dialysis-centers", async (req, res) => {
    try {
      const validation = insertDialysisCenterSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid dialysis center data", errors: validation.error.errors });
      }
      
      const dialysisCenter = await storage.createDialysisCenter(validation.data);
      res.status(201).json(dialysisCenter);
    } catch (error) {
      res.status(500).json({ message: "Failed to create dialysis center" });
    }
  });

  // Emergency Services routes
  app.get("/api/emergency-services", async (req, res) => {
    try {
      const emergencyServices = await storage.getAllEmergencyServices();
      res.json(emergencyServices);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch emergency services" });
    }
  });

  app.get("/api/emergency-services/:id", async (req, res) => {
    try {
      const emergencyService = await storage.getEmergencyService(req.params.id);
      if (!emergencyService) {
        return res.status(404).json({ message: "Emergency service not found" });
      }
      res.json(emergencyService);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch emergency service" });
    }
  });

  app.post("/api/emergency-services", async (req, res) => {
    try {
      const validation = insertEmergencyServiceSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid emergency service data", errors: validation.error.errors });
      }
      
      const emergencyService = await storage.createEmergencyService(validation.data);
      res.status(201).json(emergencyService);
    } catch (error) {
      res.status(500).json({ message: "Failed to create emergency service" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
