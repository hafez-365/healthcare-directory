import { 
  type Hospital, 
  type InsertHospital,
  type HealthUnit,
  type InsertHealthUnit,
  type DialysisCenter,
  type InsertDialysisCenter,
  type EmergencyService,
  type InsertEmergencyService
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Hospitals
  getHospital(id: string): Promise<Hospital | undefined>;
  getAllHospitals(): Promise<Hospital[]>;
  createHospital(hospital: InsertHospital): Promise<Hospital>;
  
  // Health Units
  getHealthUnit(id: string): Promise<HealthUnit | undefined>;
  getAllHealthUnits(): Promise<HealthUnit[]>;
  createHealthUnit(healthUnit: InsertHealthUnit): Promise<HealthUnit>;
  
  // Dialysis Centers
  getDialysisCenter(id: string): Promise<DialysisCenter | undefined>;
  getAllDialysisCenters(): Promise<DialysisCenter[]>;
  createDialysisCenter(dialysisCenter: InsertDialysisCenter): Promise<DialysisCenter>;
  
  // Emergency Services
  getEmergencyService(id: string): Promise<EmergencyService | undefined>;
  getAllEmergencyServices(): Promise<EmergencyService[]>;
  createEmergencyService(emergencyService: InsertEmergencyService): Promise<EmergencyService>;
}

export class MemStorage implements IStorage {
  private hospitals: Map<string, Hospital>;
  private healthUnits: Map<string, HealthUnit>;
  private dialysisCenters: Map<string, DialysisCenter>;
  private emergencyServices: Map<string, EmergencyService>;

  constructor() {
    this.hospitals = new Map();
    this.healthUnits = new Map();
    this.dialysisCenters = new Map();
    this.emergencyServices = new Map();
    this.seedData();
  }

  private seedData() {
    const hospitalData: Omit<Hospital, 'id'>[] = [
      {
        name: "مستشفى دمنهور العام",
        address: "شارع الجمهورية - دمنهور - البحيرة",
        phone: "045/3318337",
        beds: "250 سرير",
        services: [
          "قسم الطوارئ",
          "العناية المركزة", 
          "الجراحة العامة",
          "الطب الباطني",
          "النساء والولادة",
          "طب الأطفال",
          "الأشعة والتصوير الطبي",
          "المختبرات الطبية"
        ],
        workingHours: "24 ساعة - 7 أيام في الأسبوع",
        doctors: [
          { name: "د. أحمد محمد السيد", specialty: "أخصائي جراحة عامة" },
          { name: "د. فاطمة علي حسن", specialty: "أخصائية نساء وولادة" },
          { name: "د. محمود عبد العزيز", specialty: "أخصائي طب باطني" },
          { name: "د. نادية محمد أحمد", specialty: "أخصائية طب أطفال" }
        ],
        description: "مستشفى دمنهور العام هو المركز الطبي الرئيسي في عاصمة محافظة البحيرة ويقدم خدمات طبية شاملة للمرضى من جميع أنحاء المحافظة."
      },
      {
        name: "مستشفى دمنهور التعليمي",
        address: "شارع الجمهورية أمام كلية الآداب - دمنهور - البحيرة",
        phone: "045/3328800",
        beds: "300 سرير",
        services: [
          "قسم الطوارئ المتطور",
          "وحدة العناية المركزة",
          "قسم أمراض الكلى وغسيل الكلى",
          "قسم الجراحة التخصصية",
          "قسم الأطفال وحديثي الولادة",
          "زراعة الكلى",
          "قسم الأشعة المتقدمة",
          "المختبرات الشاملة"
        ],
        workingHours: "24 ساعة - 7 أيام في الأسبوع",
        doctors: [
          { name: "د. محمد عبد الرحمن", specialty: "استشاري أمراض الكلى" },
          { name: "د. سارة أحمد عبدالله", specialty: "أخصائية أمراض باطنة" },
          { name: "د. عمر حسن محمد", specialty: "أخصائي طب الأطفال" },
          { name: "د. ليلى محمد علي", specialty: "أخصائية تخدير وعناية مركزة" }
        ],
        description: "مستشفى دمنهور التعليمي هو أكبر المستشفيات في المحافظة ويوفر خدمات طبية متقدمة ومتنوعة مع التعليم الطبي، ويضم الوحدة الوحيدة للغسيل البريتوني على مستوى الجمهورية."
      },
      {
        name: "مستشفى دمنهور العسكري",
        address: "دمنهور - البحيرة",
        phone: "045/3307740",
        beds: "118 سرير",
        services: [
          "الطوارئ والإسعاف",
          "الجراحة التخصصية",
          "طب وجراحة العيون",
          "قسم الأسنان المتكامل",
          "الطب النفسي والعصبي",
          "إعادة التأهيل الطبي",
          "الفحوصات الشاملة",
          "الطب الرياضي"
        ],
        workingHours: "24 ساعة - 7 أيام في الأسبوع",
        doctors: [
          { name: "د. خالد أحمد منصور", specialty: "استشاري جراحة تخصصية" },
          { name: "د. منى سعد إبراهيم", specialty: "أخصائية طب عيون" },
          { name: "د. أحمد محمد زكي", specialty: "أخصائي طب نفسي" },
          { name: "د. رانيا علي حسن", specialty: "أخصائية طب أسنان" }
        ],
        description: "مستشفى دمنهور العسكري يقدم خدمات طبية متميزة بأحدث التقنيات الطبية على مساحة 4.5 فدان بتكلفة 326 مليون جنيه."
      },
      {
        name: "مستشفى كفر الدوار العام",
        address: "كفر الدوار - البحيرة",
        phone: "045/2212588",
        beds: "180 سرير",
        services: [
          "قسم الطوارئ",
          "وحدة عناية القلب",
          "الجراحة العامة",
          "الطب الباطني",
          "النساء والولادة",
          "طب الأطفال",
          "العظام والمفاصل",
          "الأنف والأذن والحنجرة"
        ],
        workingHours: "24 ساعة - 7 أيام في الأسبوع",
        doctors: [
          { name: "د. حسام الدين أحمد", specialty: "أخصائي أمراض القلب" },
          { name: "د. إيمان محمد سالم", specialty: "أخصائية نساء وولادة" },
          { name: "د. طارق عبد المجيد", specialty: "أخصائي طب عظام" },
          { name: "د. هالة أحمد محمد", specialty: "أخصائية طب أطفال" }
        ],
        description: "مستشفى كفر الدوار العام يخدم مدينة كفر الدوار والمناطق المجاورة ويضم وحدة عناية القلب بسعة 8 أسرة."
      },
      {
        name: "مستشفى رشيد المركزي",
        address: "رشيد - البحيرة",
        phone: "045/2950123",
        beds: "120 سرير",
        services: [
          "طوارئ الحوادث البحرية",
          "الجراحة العامة والطوارئ",
          "طب الغوص والطب البحري",
          "الإصابات الرياضية",
          "الطب الباطني",
          "العلاج الطبيعي",
          "الأشعة والمختبرات",
          "طب الأسرة"
        ],
        workingHours: "24 ساعة - 7 أيام في الأسبوع",
        doctors: [
          { name: "د. محمد صبري عبدالله", specialty: "أخصائي طب الطوارئ" },
          { name: "د. نورا حسن محمد", specialty: "أخصائية علاج طبيعي" },
          { name: "د. أحمد علي إبراهيم", specialty: "أخصائي جراحة عامة" },
          { name: "د. سمية محمد أحمد", specialty: "أخصائية طب باطني" }
        ],
        description: "مستشفى رشيد المركزي متخصص في علاج الحوادث البحرية والإصابات الرياضية في المدينة التاريخية على نيل رشيد."
      },
      {
        name: "مستشفى إيتاي البارود العام",
        address: "إيتاي البارود - البحيرة",
        phone: "045/2670330",
        beds: "100 سرير",
        services: [
          "قسم الطوارئ",
          "الطب الوقائي",
          "الجراحة العامة",
          "الطب الباطني",
          "طب الأطفال",
          "النساء والولادة",
          "طب الأسرة",
          "الصحة العامة"
        ],
        workingHours: "24 ساعة - 7 أيام في الأسبوع",
        doctors: [
          { name: "د. عبد الرحمن محمد", specialty: "أخصائي طب عام" },
          { name: "د. مريم أحمد علي", specialty: "أخصائية طب وقائي" },
          { name: "د. محمود حسن سعد", specialty: "أخصائي جراحة عامة" },
          { name: "د. فاطمة عبد العزيز", specialty: "أخصائية طب أطفال" }
        ],
        description: "مستشفى إيتاي البارود العام يخدم مركز إيتاي البارود ويوفر خدمات طبية شاملة للمجتمع المحلي."
      }
    ];

    hospitalData.forEach(hospital => {
      const id = randomUUID();
      this.hospitals.set(id, { ...hospital, id });
    });

    // Seed Health Units
    const healthUnitData: Omit<HealthUnit, 'id'>[] = [
      {
        name: "مركز طبي ناصر - دمنهور",
        address: "دمنهور - محافظة البحيرة",
        phone: "045/3318337",
        workingHours: "8:00 ص - 2:00 م",
        services: [
          "رعاية أمومة وطفولة",
          "تطعيمات الأطفال",
          "رعاية صحية أولية",
          "فحوصات دورية",
          "فحص ضغط الدم والسكر",
          "خدمات تنظيم الأسرة",
          "التثقيف الصحي"
        ],
        medicalTeam: [
          { name: "د. سارة محمد أحمد", specialty: "أخصائية أمومة وطفولة" },
          { name: "أ. أحمد علي محمود", specialty: "ممرض مشرف" },
          { name: "أ. نادية حسن إبراهيم", specialty: "ممرضة تطعيمات" }
        ],
        description: "مركز طبي ناصر في دمنهور يقدم خدمات صحية متكاملة لأهالي العاصمة، مع تركيز خاص على رعاية الأمومة والطفولة والرعاية الصحية الأولية."
      },
      {
        name: "وحدة صحية كفر الدوار",
        address: "كفر الدوار - محافظة البحيرة",
        phone: "045/2212588",
        workingHours: "8:00 ص - 3:00 م",
        services: [
          "فحص عام",
          "تطعيمات الأطفال والكبار",
          "رعاية أولية",
          "خدمات صحة المرأة",
          "فحص الأطفال"
        ],
        medicalTeam: [
          { name: "د. أمين حسام", specialty: "طب عام" },
          { name: "أ. فاطمة علي", specialty: "ممرضة رئيسية" }
        ],
        description: "وحدة صحية تخدم منطقة النجيلة وتقدم خدمات الرعاية الصحية الأولية والوقائية."
      },
      {
        name: "وحدة صحية رشيد",
        address: "رشيد - محافظة البحيرة", 
        phone: "045/2950123",
        workingHours: "7:00 ص - 2:00 م",
        services: [
          "رعاية صحية شاملة",
          "تطعيمات للأطفال والكبار",
          "خدمات الأمومة",
          "فحوصات دورية",
          "الإسعافات الأولية",
          "خدمات صحة المرأة"
        ],
        medicalTeam: [
          { name: "د. محمد صبري الرشيدي", specialty: "طب الأسرة" },
          { name: "أ. هالة أحمد محمد", specialty: "ممرضة تطعيمات" },
          { name: "أ. سمير محمد علي", specialty: "فني مختبر" }
        ],
        description: "وحدة صحية حديثة تخدم المدينة التاريخية رشيد وتوفر خدمات صحية متنوعة للمجتمع المحلي والصيادين."
      }
    ];

    healthUnitData.forEach(unit => {
      const id = randomUUID();
      this.healthUnits.set(id, { ...unit, id });
    });

    // Seed Dialysis Centers
    const dialysisCenterData: Omit<DialysisCenter, 'id'>[] = [
      {
        name: "مركز دمنهور التعليمي لغسيل الكلى",
        address: "شارع الجمهورية أمام كلية الآداب - دمنهور - البحيرة",
        phone: "045/3328800",
        workingHours: "24 ساعة - 7 أيام في الأسبوع",
        capacity: "25 جهاز غسيل كلى",
        services: [
          "غسيل الكلى الدموي",
          "غسيل الكلى البريتوني (الوحيد على مستوى الجمهورية)",
          "زراعة الكلى",
          "فحوصات شاملة للكلى",
          "استشارات طبية متخصصة",
          "خدمات التغذية العلاجية",
          "متابعة ما بعد زراعة الكلى"
        ],
        equipment: [
          "أجهزة غسيل كلى حديثة من أحدث الأجيال",
          "أجهزة مراقبة حيوية متطورة",
          "معمل تحاليل مجهز بالكامل",
          "وحدة عناية مكثفة متخصصة",
          "أجهزة الغسيل البريتوني المتقدمة"
        ],
        description: "مركز دمنهور التعليمي لغسيل الكلى هو المركز الرئيسي لعلاج أمراض الكلى في محافظة البحيرة ومحافظة كفر الشيخ، ويضم الوحدة الوحيدة للغسيل البريتوني على مستوى الجمهورية، ويقدم خدمات مجانية على نفقة الدولة."
      },
      {
        name: "مركز كفر الدوار لغسيل الكلى", 
        address: "كفر الدوار - محافظة البحيرة",
        phone: "045/2212588",
        workingHours: "6:00 ص - 10:00 م",
        capacity: "15 جهاز غسيل كلى",
        services: [
          "غسيل الكلى الدموي",
          "متابعة حالات الكلى المزمنة",
          "فحوصات دورية",
          "إرشادات غذائية",
          "خدمات التأهيل النفسي"
        ],
        equipment: [
          "أجهزة غسيل كلى متطورة",
          "أنظمة تعقيم متقدمة",
          "معدات طوارئ",
          "أجهزة فحص وظائف الكلى"
        ],
        description: "مركز حديث يخدم مدينة كفر الدوار والمناطق المجاورة ويقدم خدمات غسيل الكلى بجودة عالية ومجاناً على نفقة الدولة."
      }
    ];

    dialysisCenterData.forEach(center => {
      const id = randomUUID();
      this.dialysisCenters.set(id, { ...center, id });
    });

    // Seed Emergency Services
    const emergencyServiceData: Omit<EmergencyService, 'id'>[] = [
      {
        name: "الإسعاف المركزي - البحيرة",
        type: "ambulance",
        phone: "123",
        address: "دمنهور - مقر المحافظة",
        coverage: "محافظة البحيرة كاملة",
        availability: "24 ساعة - 7 أيام في الأسبوع",
        description: "خدمة الإسعاف المركزية لمحافظة البحيرة تغطي جميع المراكز والمدن في المحافظة وتوفر الرعاية الطارئة والنقل الطبي."
      },
      {
        name: "إسعاف مستشفى دمنهور العام",
        type: "hospital",
        phone: "045/3318337",
        address: "شارع الجمهورية - دمنهور",
        coverage: "دمنهور والمناطق المجاورة", 
        availability: "24 ساعة - 7 أيام في الأسبوع",
        description: "وحدة الإسعاف في مستشفى دمنهور العام تقدم خدمات الطوارئ الطبية والإسعافات الأولية لعاصمة المحافظة."
      },
      {
        name: "الدفاع المدني - البحيرة",
        type: "fire",
        phone: "180",
        address: "دمنهور - البحيرة",
        coverage: "محافظة البحيرة",
        availability: "24 ساعة - 7 أيام في الأسبوع", 
        description: "مديرية الدفاع المدني بالبحيرة تقدم خدمات الإطفاء والإنقاذ ومكافحة الحرائق في جميع مراكز المحافظة."
      },
      {
        name: "شرطة النجدة - البحيرة",
        type: "police",
        phone: "122",
        address: "مديرية الأمن - دمنهور",
        coverage: "محافظة البحيرة",
        availability: "24 ساعة - 7 أيام في الأسبوع",
        description: "خدمة شرطة النجدة تقدم المساعدة الأمنية الفورية وتلبي طلبات الطوارئ الأمنية في جميع أنحاء المحافظة."
      },
      {
        name: "غرفة عمليات الأمن - البحيرة",
        type: "police",
        phone: "045/3307742",
        address: "مديرية أمن البحيرة - دمنهور",
        coverage: "محافظة البحيرة",
        availability: "24 ساعة - 7 أيام في الأسبوع",
        description: "غرفة العمليات بمديرية الأمن تنسق العمليات الأمنية وتتلقى البلاغات والطوارئ من جميع أنحاء المحافظة."
      }
    ];

    emergencyServiceData.forEach(service => {
      const id = randomUUID();
      this.emergencyServices.set(id, { ...service, id });
    });
  }

  // Hospital methods
  async getHospital(id: string): Promise<Hospital | undefined> {
    return this.hospitals.get(id);
  }

  async getAllHospitals(): Promise<Hospital[]> {
    return Array.from(this.hospitals.values());
  }

  async createHospital(insertHospital: InsertHospital): Promise<Hospital> {
    const id = randomUUID();
    const hospital: Hospital = { ...insertHospital, id };
    this.hospitals.set(id, hospital);
    return hospital;
  }

  // Health Unit methods
  async getHealthUnit(id: string): Promise<HealthUnit | undefined> {
    return this.healthUnits.get(id);
  }

  async getAllHealthUnits(): Promise<HealthUnit[]> {
    return Array.from(this.healthUnits.values());
  }

  async createHealthUnit(insertHealthUnit: InsertHealthUnit): Promise<HealthUnit> {
    const id = randomUUID();
    const healthUnit: HealthUnit = { ...insertHealthUnit, id };
    this.healthUnits.set(id, healthUnit);
    return healthUnit;
  }

  // Dialysis Center methods
  async getDialysisCenter(id: string): Promise<DialysisCenter | undefined> {
    return this.dialysisCenters.get(id);
  }

  async getAllDialysisCenters(): Promise<DialysisCenter[]> {
    return Array.from(this.dialysisCenters.values());
  }

  async createDialysisCenter(insertDialysisCenter: InsertDialysisCenter): Promise<DialysisCenter> {
    const id = randomUUID();
    const dialysisCenter: DialysisCenter = { ...insertDialysisCenter, id };
    this.dialysisCenters.set(id, dialysisCenter);
    return dialysisCenter;
  }

  // Emergency Service methods
  async getEmergencyService(id: string): Promise<EmergencyService | undefined> {
    return this.emergencyServices.get(id);
  }

  async getAllEmergencyServices(): Promise<EmergencyService[]> {
    return Array.from(this.emergencyServices.values());
  }

  async createEmergencyService(insertEmergencyService: InsertEmergencyService): Promise<EmergencyService> {
    const id = randomUUID();
    const emergencyService: EmergencyService = { ...insertEmergencyService, id };
    this.emergencyServices.set(id, emergencyService);
    return emergencyService;
  }
}

export const storage = new MemStorage();
