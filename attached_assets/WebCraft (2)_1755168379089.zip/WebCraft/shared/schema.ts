import { pgTable, text, varchar, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const hospitals = pgTable("hospitals", {
  id: varchar("id").primaryKey(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  phone: text("phone").notNull(),
  beds: text("beds").notNull(),
  services: json("services").$type<string[]>().notNull(),
  workingHours: text("working_hours").notNull(),
  doctors: json("doctors").$type<Array<{name: string, specialty: string}>>().notNull(),
  description: text("description").notNull(),
});

export const healthUnits = pgTable("health_units", {
  id: varchar("id").primaryKey(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  phone: text("phone").notNull(),
  workingHours: text("working_hours").notNull(),
  services: json("services").$type<string[]>().notNull(),
  medicalTeam: json("medical_team").$type<Array<{name: string, specialty: string}>>().notNull(),
  description: text("description").notNull(),
});

export const dialysisCenters = pgTable("dialysis_centers", {
  id: varchar("id").primaryKey(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  phone: text("phone").notNull(),
  workingHours: text("working_hours").notNull(),
  capacity: text("capacity").notNull(),
  services: json("services").$type<string[]>().notNull(),
  equipment: json("equipment").$type<string[]>().notNull(),
  description: text("description").notNull(),
});

export const emergencyServices = pgTable("emergency_services", {
  id: varchar("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // "ambulance", "fire", "police", "hospital"
  phone: text("phone").notNull(),
  address: text("address").notNull(),
  coverage: text("coverage").notNull(),
  availability: text("availability").notNull(),
  description: text("description").notNull(),
});

export const insertHospitalSchema = createInsertSchema(hospitals);
export const insertHealthUnitSchema = createInsertSchema(healthUnits);
export const insertDialysisCenterSchema = createInsertSchema(dialysisCenters);
export const insertEmergencyServiceSchema = createInsertSchema(emergencyServices);

export type InsertHospital = z.infer<typeof insertHospitalSchema>;
export type Hospital = typeof hospitals.$inferSelect;
export type InsertHealthUnit = z.infer<typeof insertHealthUnitSchema>;
export type HealthUnit = typeof healthUnits.$inferSelect;
export type InsertDialysisCenter = z.infer<typeof insertDialysisCenterSchema>;
export type DialysisCenter = typeof dialysisCenters.$inferSelect;
export type InsertEmergencyService = z.infer<typeof insertEmergencyServiceSchema>;
export type EmergencyService = typeof emergencyServices.$inferSelect;
