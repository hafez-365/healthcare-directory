import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { type DialysisCenter } from '@shared/schema';
import { Layout } from '@/components/ui/layout';
import { MapPin, Phone, Clock, ChevronRight, Activity } from 'lucide-react';

export default function DialysisCenters() {
  const [selectedFilter, setSelectedFilter] = useState<string>('المسافة');

  const { data: dialysisCenters, isLoading, error } = useQuery<DialysisCenter[]>({
    queryKey: ['/api/dialysis-centers'],
  });

  if (isLoading) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-rose-900"></div>
        </div>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">حدث خطأ في تحميل البيانات</h2>
            <p className="text-gray-600">يرجى المحاولة مرة أخرى لاحقاً</p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      {/* Search and Filter Section */}
      <section className="bg-white rounded-xl shadow-md p-6 mb-8">
        <div className="flex flex-col lg:flex-row justify-between items-center gap-4">
          {/* Results Counter */}
          <div className="flex items-center text-sm">
            <span className="text-gray-700">إجمالي</span>
            <span className="text-rose-600 font-bold mx-2 text-lg" data-testid="dialysis-centers-count">
              {dialysisCenters?.length || 0}
            </span>
            <span className="text-gray-700">مركز غسيل كلى</span>
          </div>
          
          {/* Search and Sort Controls */}
          <div className="flex flex-col sm:flex-row items-center gap-3 w-full lg:w-auto">
            <div className="flex items-center w-full sm:w-auto">
              <select 
                value={selectedFilter}
                onChange={(e) => setSelectedFilter(e.target.value)}
                className="border border-gray-300 px-4 py-2 rounded-r-md text-sm bg-white text-gray-900 focus:ring-2 focus:ring-rose-500 focus:border-rose-500 w-full sm:w-auto"
                data-testid="filter-select"
              >
                <option value="المسافة">ترتيب حسب المسافة</option>
                <option value="الاسم">أ إلى ي</option>
                <option value="السعة">السعة</option>
              </select>
              <button 
                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-l-md text-sm transition-colors whitespace-nowrap"
                data-testid="button-search-nearby"
              >
                البحث عن الأقرب
              </button>
            </div>
            
            <button 
              className="bg-rose-900 hover:bg-rose-800 text-white px-4 py-2 rounded-md text-sm flex items-center gap-2 transition-colors w-full sm:w-auto justify-center"
              data-testid="button-get-location"
            >
              <MapPin className="h-4 w-4" />
              تحديد موقعك
            </button>
          </div>
        </div>
      </section>

      {/* Dialysis Centers Grid */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {dialysisCenters?.map((center) => (
          <div 
            key={center.id} 
            className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden group"
            data-testid={`card-dialysis-center-${center.id}`}
          >
            <div className="p-6">
              {/* Center Name */}
              <div className="flex items-center mb-4">
                <div className="bg-blue-100 p-2 rounded-full ml-3">
                  <Activity className="h-5 w-5 text-blue-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 group-hover:text-rose-900 transition-colors">
                  {center.name}
                </h3>
              </div>
              
              {/* Address */}
              <div className="flex items-start mb-3">
                <MapPin className="h-5 w-5 text-rose-500 mt-0.5 ml-3 flex-shrink-0" />
                <span className="text-gray-700 text-sm leading-relaxed">
                  {center.address}
                </span>
              </div>
              
              {/* Phone */}
              <div className="flex items-center mb-3">
                <Phone className="h-5 w-5 text-blue-600 ml-3 flex-shrink-0" />
                <a 
                  href={`tel:${center.phone}`} 
                  className="text-gray-700 text-sm hover:text-blue-600 transition-colors"
                  data-testid={`link-phone-${center.id}`}
                >
                  {center.phone}
                </a>
              </div>
              
              {/* Working Hours */}
              <div className="flex items-center mb-3">
                <Clock className="h-5 w-5 text-green-600 ml-3 flex-shrink-0" />
                <span className="text-gray-700 text-sm">{center.workingHours}</span>
              </div>

              {/* Capacity */}
              <div className="flex items-center mb-4">
                <Activity className="h-5 w-5 text-purple-600 ml-3 flex-shrink-0" />
                <span className="text-gray-700 text-sm font-medium">{center.capacity}</span>
              </div>
              
              {/* Services */}
              <div className="mb-6">
                <h4 className="font-semibold text-sm text-gray-900 mb-2">الخدمات المقدمة:</h4>
                <div className="flex flex-wrap gap-2">
                  {center.services.slice(0, 2).map((service, index) => (
                    <span 
                      key={index}
                      className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium"
                    >
                      {service}
                    </span>
                  ))}
                  {center.services.length > 2 && (
                    <span className="text-xs text-gray-500">
                      +{center.services.length - 2} خدمات أخرى
                    </span>
                  )}
                </div>
              </div>
              
              {/* Action Buttons */}
              <div className="flex gap-2">
                <Link 
                  to={`/dialysis-centers/${center.id}`}
                  className="flex-1 bg-rose-900 hover:bg-rose-800 text-white text-sm px-3 py-2 rounded-md transition-colors flex items-center justify-center"
                  data-testid={`button-details-${center.id}`}
                >
                  عرض التفاصيل
                  <ChevronRight className="h-4 w-4 mr-1" />
                </Link>
                <a 
                  href={`tel:${center.phone}`}
                  className="bg-green-600 hover:bg-green-700 text-white px-3 py-2 rounded-md transition-colors flex items-center justify-center"
                  data-testid={`button-call-${center.id}`}
                >
                  <Phone className="h-4 w-4" />
                </a>
              </div>
            </div>
          </div>
        ))}
      </section>
    </Layout>
  );
}