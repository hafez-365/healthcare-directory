import { ReactNode } from 'react';
import { Link } from 'wouter';
import { useI18n } from '@/lib/i18n';

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const { language, t, toggleLanguage } = useI18n();
  
  return (
    <div dir={language === 'ar' ? 'rtl' : 'ltr'} className="min-h-screen bg-gray-50 font-cairo">
      {/* Header */}
      <header className="bg-rose-900 text-white shadow-lg">
        {/* Top Header with Logo and Language Toggle */}
        <div className="border-b border-rose-800">
          <div className="container mx-auto px-4 py-3 flex justify-between items-center">
            {/* Logo/Brand */}
            <div className="flex items-center space-x-reverse space-x-3">
              <div className="h-10 w-10 bg-white rounded-lg flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-rose-900" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                </svg>
              </div>
              <div>
                <h1 className="text-lg font-bold" data-testid="text-site-title">{t('site.title')}</h1>
                <p className="text-xs text-rose-200" data-testid="text-site-subtitle">{t('site.subtitle')}</p>
              </div>
            </div>
            
            {/* Language Toggle */}
            <button 
              onClick={toggleLanguage}
              className="bg-white text-rose-900 px-4 py-2 rounded-md text-sm font-medium hover:bg-rose-50 transition-colors"
              data-testid="button-language-toggle"
            >
              {language === 'ar' ? 'EN' : 'عربي'}
            </button>
          </div>
        </div>

        {/* Navigation Menu */}
        <nav className="container mx-auto px-4 py-4">
          <ul className="flex flex-wrap justify-center gap-6 text-sm">
            <li><Link href="/" className="text-white hover:text-rose-200 transition-colors" data-testid="link-nav-home">{t('nav.home')}</Link></li>
            <li><Link href="/hospitals" className="text-white hover:text-rose-200 transition-colors" data-testid="link-nav-hospitals">{t('nav.hospitals')}</Link></li>
            <li><Link href="/health-units" className="text-white hover:text-rose-200 transition-colors" data-testid="link-nav-health-units">{t('nav.health_units')}</Link></li>
            <li><Link href="/dialysis-centers" className="text-white hover:text-rose-200 transition-colors" data-testid="link-nav-dialysis">{t('nav.dialysis')}</Link></li>
            <li><Link href="/emergency-services" className="text-white hover:text-rose-200 transition-colors" data-testid="link-nav-emergency">{t('nav.emergency')}</Link></li>
            <li><Link href="#" className="text-white hover:text-rose-200 transition-colors" data-testid="link-nav-hotlines">{t('nav.hotlines')}</Link></li>
            <li><Link href="#" className="text-white hover:text-rose-200 transition-colors" data-testid="link-nav-highway">{t('nav.highway')}</Link></li>
            <li><Link href="#" className="text-white hover:text-rose-200 transition-colors" data-testid="link-nav-contact">{t('nav.contact')}</Link></li>
          </ul>
        </nav>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6 max-w-7xl">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-rose-900 text-white mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Contact Info */}
            <div>
              <h3 className="text-lg font-bold mb-4">{t('footer.contact')}</h3>
              <ul className="space-y-2 text-sm text-rose-100">
                <li className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.762 1.212l-4.906 1.14a8 8 0 00-3.5 12.29l4.906 1.14a1 1 0 01.762 1.212l1.498 4.493a1 1 0 01-.948 1.323H5a2 2 0 01-2-2v-3.28A10.01 10.01 0 013 5z" />
                  </svg>
                  {t('footer.hotline')}
                </li>
                <li className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                  {t('footer.location')}
                </li>
              </ul>
            </div>
            
            {/* Quick Links */}
            <div>
              <h3 className="text-lg font-bold mb-4">{t('footer.quick_links')}</h3>
              <ul className="space-y-2 text-sm text-rose-100">
                <li><Link href="/hospitals" className="hover:text-white transition-colors">{t('nav.hospitals')}</Link></li>
                <li><Link href="/health-units" className="hover:text-white transition-colors">{t('nav.health_units')}</Link></li>
                <li><Link href="/dialysis-centers" className="hover:text-white transition-colors">{t('nav.dialysis')}</Link></li>
                <li><Link href="/emergency-services" className="hover:text-white transition-colors">{t('nav.emergency')}</Link></li>
              </ul>
            </div>
            
            {/* About */}
            <div>
              <h3 className="text-lg font-bold mb-4">{t('footer.about')}</h3>
              <p className="text-sm text-rose-100 leading-relaxed">
                {t('footer.about.desc')}
              </p>
            </div>
          </div>
          
          {/* Copyright */}
          <div className="border-t border-rose-800 mt-8 pt-6 text-center">
            <p className="text-rose-200 text-sm">
              {t('footer.copyright')}
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
