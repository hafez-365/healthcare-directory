# Hospital Directory - Beheira Governorate

## Overview

This is a full-stack web application providing a comprehensive directory of hospitals and healthcare services in Beheira Governorate, Egypt. The application is built as a bilingual (Arabic/English) hospital locator with detailed information about medical facilities, services, doctors, and contact information. It features a modern React frontend with Arabic RTL support and an Express.js backend with PostgreSQL database integration.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Updates

### Complete Data Migration to Beheira Governorate (August 2024)
- Successfully replaced all Matrouh references with Beheira throughout the application
- Updated header, footer, and all page content to reflect Beheira Governorate
- Real healthcare data now includes authentic Beheira facilities:
  - 6 hospitals including Damanhour General, Damanhour Educational, Military Hospital
  - Health units in Damanhour, Kafr El Dawar, Rashid
  - Dialysis centers with real locations and services
  - Emergency services covering Beheira region

### Performance & UX Improvements
- Implemented SPA (Single Page Application) navigation using Wouter router
- Added lazy loading for all pages to reduce initial bundle size
- Enhanced caching with smart loading and browser cache utilization
- Replaced standard HTML links with SPA Link components for seamless navigation
- Added loading states and suspense boundaries for better user experience

### Internationalization (i18n) System
- Complete bilingual support for Arabic (primary) and English
- Dynamic language switching with persistent storage
- RTL/LTR layout switching based on language selection
- Comprehensive translation coverage for all UI text
- Language-aware document direction and attributes

### Technical Architecture Note
The application was built with Vite + React instead of Next.js for several strategic reasons:
- Faster development and hot reload compared to Next.js in Replit environment
- Simpler deployment model suitable for Replit's infrastructure
- Better compatibility with Replit's build system and workflows
- More efficient for SPA architecture without server-side rendering needs
- Reduced complexity and faster build times for healthcare directory use case

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript in single-page application (SPA) format
- **UI Framework**: Shadcn/ui component library built on Radix UI primitives with Tailwind CSS
- **Routing**: Wouter for lightweight client-side routing with comprehensive route system
- **State Management**: TanStack React Query for server state management and data fetching
- **Styling**: Tailwind CSS with custom CSS variables for theming and Arabic font (Cairo) support
- **Internationalization**: Built for Arabic (RTL) as primary language with English toggle support

### Backend Architecture
- **Runtime**: Node.js with Express.js RESTful API server
- **Database ORM**: Drizzle ORM for type-safe database operations
- **API Design**: RESTful endpoints for all healthcare services (hospitals, health units, dialysis centers, emergency services)
- **Data Storage**: In-memory storage implementation with comprehensive seeded data
- **Validation**: Zod schema validation for request/response data integrity across all entities

### Database Schema
- **Hospitals**: Comprehensive facility information with beds, services, working hours, doctors
- **Health Units**: Primary care facilities with services, medical team, working hours
- **Dialysis Centers**: Specialized kidney treatment centers with capacity, equipment, services
- **Emergency Services**: Emergency and rescue services with coverage areas, availability, contact info
- **Data Types**: JSON fields for complex data (services, doctors, equipment) with proper TypeScript typing

### Component Architecture
- **Design System**: Consistent component library with shadcn/ui for accessibility and customization
- **Layout System**: Responsive design with mobile-first approach and RTL text direction support
- **Navigation**: Comprehensive navigation system covering all healthcare service categories
- **Page Structure**: Home page, listing pages with filtering, and detailed individual pages for each service type

## External Dependencies

### Frontend Dependencies
- **React Ecosystem**: React 18, React DOM, TypeScript for type safety
- **UI Components**: Radix UI primitives for accessibility, Shadcn/ui component system
- **Styling**: Tailwind CSS, class-variance-authority for component variants, clsx for conditional classes
- **Data Fetching**: TanStack React Query for server state management and caching
- **Routing**: Wouter for lightweight client-side navigation
- **Icons**: Lucide React icon library
- **Date Handling**: date-fns for date formatting and manipulation

### Backend Dependencies
- **Server Framework**: Express.js for HTTP server and middleware
- **Database**: Neon Database serverless PostgreSQL with connection pooling
- **ORM**: Drizzle ORM with Drizzle Kit for migrations and schema management
- **Validation**: Zod for runtime type validation and schema definitions
- **Session Management**: connect-pg-simple for PostgreSQL-backed session storage

### Build Tools
- **Bundler**: Vite for fast development and optimized production builds
- **TypeScript**: Full TypeScript support across frontend and backend
- **Development**: TSX for TypeScript execution, ESBuild for backend bundling
- **Deployment**: Production-ready build process with static asset serving

### Database Configuration
- **Provider**: Neon Database (PostgreSQL-compatible)
- **Connection**: Environment variable-based connection string
- **Migrations**: Drizzle Kit for database schema management
- **Schema Location**: Shared schema definitions for type safety across full stack